# Card Golf Score Tracker Android App

This is a lightweight Android WebView app that wraps the standalone Card Golf HTML score tracker.

## Build an APK

1. Open this folder in Android Studio.
2. Let Android Studio sync Gradle.
3. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Install the generated APK on your Android device.

The app works offline and stores scores locally on the device through WebView local storage.
